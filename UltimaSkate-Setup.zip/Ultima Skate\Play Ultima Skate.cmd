@echo off
rem Updates Ultima Skate from your friend's PC, then starts it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UltimaSkateLauncher.ps1" %*
if errorlevel 1 pause
