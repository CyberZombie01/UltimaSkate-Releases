@echo off
rem Updates Ultima Skate from GitHub, then starts it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UltimaSkateLauncher.ps1" %*
if errorlevel 1 pause
