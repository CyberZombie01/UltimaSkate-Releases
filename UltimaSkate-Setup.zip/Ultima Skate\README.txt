ULTIMA SKATE

1. Unzip this folder anywhere you like (e.g. Documents\Ultima Skate). Nothing else to install.
2. Double-click "Play Ultima Skate".
   The first time it downloads the whole game (about 1.5 GB) from your friend's PC - their update server has to be
   running - and may ask Windows for permission to install the Visual C++ runtime games need.
   After that it only downloads what changed, then starts the game. If your friend's PC is off, you play the
   version you already have.

Always start the game with "Play Ultima Skate" so you stay on the same version as your friends: online play only
works between matching versions.

If Windows SmartScreen warns about a file: More info > Run anyway.
To play together: Pause menu (H / Menu button) > Online > type the join code your friend gives you.
