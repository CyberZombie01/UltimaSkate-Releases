ULTIMA SKATE

0. Before unzipping: right-click UltimaSkate-Setup.zip > Properties > tick "Unblock" (bottom of the General tab) >
   OK. Windows' Smart App Control otherwise blocks "Play Ultima Skate" because it came from the internet.
   (Already unzipped? Delete the folder, unblock the zip, and unzip it again.)
1. Unzip this folder anywhere you like (e.g. Documents\Ultima Skate). Nothing else to install.
2. Double-click "Play Ultima Skate".
   The first time it downloads the whole game (about 4 GB) from GitHub and may ask Windows for permission to
   install the Visual C++ runtime games need.
   After that it only downloads what changed, then starts the game. With no internet you play the version you
   already have.

After the first install an "Ultima Skate" shortcut (with the game's deck icon) appears in this folder: it does the
same as "Play Ultima Skate", so you can drag it to your desktop.

Always start the game with "Play Ultima Skate" (or that shortcut) so you stay on the same version as your friends: online play only
works between matching versions.

If Windows SmartScreen warns about a file: More info > Run anyway.
To play together: Pause menu (H / Menu button) > Online > type the join code your friend gives you.
