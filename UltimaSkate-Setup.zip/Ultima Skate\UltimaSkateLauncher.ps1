﻿<#
  Ultima Skate launcher: updates the game from your friend's PC (the host), then starts it.

  - Asks the host's update server (addresses in update.json) for the latest build, downloads only the files that
    changed (checked by SHA-256), removes files the new build no longer has, and starts the game.
  - The host's PC off or out of reach: plays the build you have.
  - Everything the game needs comes with it (the UO data it uses is in UOClient): nothing else to install.
  Started by "Play Ultima Skate.cmd". Extra arguments are passed to the game.
#>
param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GameArgs)
$ErrorActionPreference = "Stop"
$Dir = $PSScriptRoot
$State = Join-Path $Dir ".launcher"
New-Item -ItemType Directory -Force $State | Out-Null
$Host.UI.RawUI.WindowTitle = "Ultima Skate"
[Net.ServicePointManager]::DefaultConnectionLimit = 8

function Say($Text, $Color = "Gray") { Write-Host $Text -ForegroundColor $Color }
function ReadJson($Path) { if (Test-Path $Path) { Get-Content $Path -Raw | ConvertFrom-Json } else { $null } }
function SaveJson($Path, $Obj) { [IO.File]::WriteAllText($Path, ($Obj | ConvertTo-Json -Depth 5 -Compress), (New-Object Text.UTF8Encoding($false))) }

Say ""
Say "  ULTIMA SKATE" Yellow
Say ""

$Config = ReadJson (Join-Path $Dir "update.json")
$Installed = ReadJson (Join-Path $State "installed.json")

function Request($Url, $TimeoutMs) {
    $R = [Net.HttpWebRequest]::Create($Url)
    $R.Headers.Add("X-Skate-Key", $Config.key)
    $R.Timeout = $TimeoutMs
    $R.ReadWriteTimeout = 30000
    $R.KeepAlive = $true
    return $R
}

function GetText($Url, $TimeoutMs) {
    $Resp = (Request $Url $TimeoutMs).GetResponse()
    try { (New-Object IO.StreamReader($Resp.GetResponseStream())).ReadToEnd() } finally { $Resp.Close() }
}

# --- 1. Find the host's update server -------------------------------------------------------------------------------------
$Server = $null
$Latest = $null
if ($Config -and $Config.servers) {
    Say "  Checking for updates..."
    foreach ($S in $Config.servers) {
        try {
            $Latest = (GetText "http://$S/manifest.json" 3000) | ConvertFrom-Json
            $Server = $S
            break
        } catch { }
    }
}

# --- 2. Update ---------------------------------------------------------------------------------------------------------------
$Exe = Join-Path $Dir "UltimaSkate.exe"
if ($Latest) {
    $Have = @{}
    if ($Installed) { foreach ($F in $Installed.files) { $Have[$F.path] = $F } }
    $Need = @()
    foreach ($F in $Latest.files) {
        $Local = Join-Path $Dir ($F.path -replace '/', '\')
        $Old = $Have[$F.path]
        if (-not (Test-Path $Local) -or (Get-Item $Local).Length -ne $F.size) { $Need += $F; continue }
        if ($Old -and $Old.sha256 -eq $F.sha256) { continue }
        # Already there from an install that was cut short (or copied in): keep it if it's the right file.
        if ((Get-FileHash $Local -Algorithm SHA256).Hash.ToLower() -ne $F.sha256) { $Need += $F }
    }
    if ($Need.Count -eq 0) {
        Say ("  Up to date (build {0})." -f $Latest.build) Green
    } else {
        if (Get-Process UltimaSkate -ErrorAction SilentlyContinue) {
            Say "  Ultima Skate is still running - close it, then start Play Ultima Skate again." Yellow
            exit 1
        }
        # Windows can't handle paths over 260 characters: the folder has to be short enough for the game's deepest file.
        $Deepest = ($Latest.files | ForEach-Object { $_.path.Length } | Measure-Object -Maximum).Maximum
        if ($Dir.Length + 1 + $Deepest -gt 255) {
            Say "  This folder's path is too long for Windows. Move the Ultima Skate folder somewhere shorter," Red
            Say "  like Documents\Ultima Skate or C:\Games\Ultima Skate, and start it again."
            exit 1
        }
        $Bytes = ($Need | Measure-Object -Property size -Sum).Sum
        $What = if ($Installed) { "Updating to build $($Latest.build)" } else { "Installing build $($Latest.build)" }
        Say ("  {0}: {1} files, {2:N0} MB" -f $What, $Need.Count, ($Bytes / 1MB)) Cyan
        if ($Latest.notes) { Say "  What's new: $($Latest.notes)" }
        $Done = 0L
        $Buffer = New-Object byte[] (1MB)
        $Sw = [Diagnostics.Stopwatch]::StartNew()
        $Tmp = Join-Path $State "download"
        New-Item -ItemType Directory -Force $Tmp | Out-Null
        foreach ($F in $Need) {
            $Part = Join-Path $Tmp ($F.sha256.Substring(0, 24) + ".part")
            $Ok = $false
            for ($Try = 1; $Try -le 3 -and -not $Ok; $Try++) {
                try {
                    # Resume a half-finished download.
                    $Start = if (Test-Path $Part) { (Get-Item $Part).Length } else { 0 }
                    if ($Start -gt $F.size) { Remove-Item $Part; $Start = 0 }
                    if ($Start -lt $F.size) {
                        $R = Request ("http://$Server/files/" + [Uri]::EscapeUriString($F.path)) 15000
                        if ($Start -gt 0) { $R.AddRange([long]$Start) }
                        $Resp = $R.GetResponse()
                        $In = $Resp.GetResponseStream()
                        $Out = New-Object IO.FileStream($Part, [IO.FileMode]::Append)
                        try {
                            while (($N = $In.Read($Buffer, 0, $Buffer.Length)) -gt 0) {
                                $Out.Write($Buffer, 0, $N)
                                $Done += $N
                                if ($Sw.ElapsedMilliseconds -gt 250) {
                                    $Sw.Restart()
                                    $Pct = [int](100 * $Done / [Math]::Max(1, $Bytes))
                                    Write-Progress -Activity $What -Status ("{0:N0} / {1:N0} MB" -f ($Done / 1MB), ($Bytes / 1MB)) -PercentComplete ([Math]::Min(100, $Pct))
                                }
                            }
                        } finally { $Out.Close(); $Resp.Close() }
                    }
                    if (-not (Test-Path $Part)) { New-Item -ItemType File $Part | Out-Null }   # empty files
                    $Hash = (Get-FileHash $Part -Algorithm SHA256).Hash.ToLower()
                    if ($Hash -ne $F.sha256) { Remove-Item $Part; throw "checksum mismatch" }
                    $Local = Join-Path $Dir ($F.path -replace '/', '\')
                    New-Item -ItemType Directory -Force (Split-Path $Local) | Out-Null
                    Move-Item $Part $Local -Force
                    $Ok = $true
                } catch {
                    if ($Try -eq 3) {
                        Write-Progress -Activity $What -Completed
                        Say "  Download failed ($($F.path)): $($_.Exception.Message)" Red
                        Say "  Start Play Ultima Skate again to carry on where it stopped."
                        exit 1
                    }
                    Start-Sleep -Seconds 2
                }
            }
        }
        Write-Progress -Activity $What -Completed
        # Files the new build no longer has (only ones an earlier build installed; your saves are never touched).
        if ($Installed) {
            $Keep = @{}
            foreach ($F in $Latest.files) { $Keep[$F.path] = $true }
            foreach ($F in $Installed.files) {
                if (-not $Keep[$F.path]) {
                    $Local = Join-Path $Dir ($F.path -replace '/', '\')
                    if (Test-Path $Local) { Remove-Item $Local -Force }
                }
            }
        }
        Say ("  Build {0} installed." -f $Latest.build) Green
    }
    SaveJson (Join-Path $State "installed.json") $Latest
    $Installed = $Latest
} elseif ($Installed -and (Test-Path $Exe)) {
    Say ("  Couldn't reach the update server - playing build {0}." -f $Installed.build) Yellow
} else {
    Say "  Couldn't reach the update server, and the game isn't installed yet." Red
    Say "  Ask your friend to start 'Serve Updates' on their PC (and check you're on their network or Tailscale)."
    exit 1
}

# --- 3. The Windows runtime Unreal games need (first run only; Windows asks to allow it) --------------------------------------
$Prereq = Join-Path $Dir "Redist\vc_redist.x64.exe"
$Runtime = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\X64" -ErrorAction SilentlyContinue
if ((-not $Runtime -or $Runtime.Installed -ne 1) -and (Test-Path $Prereq) -and -not (Test-Path (Join-Path $State "prereqs.done"))) {
    Say "  Installing the Visual C++ runtime the game needs (one time)..."
    try {
        Start-Process -FilePath $Prereq -ArgumentList "/install", "/quiet", "/norestart" -Verb RunAs -Wait
        Set-Content (Join-Path $State "prereqs.done") "ok"
    } catch {
        Say "  Skipped the runtime install - if the game won't start, run Redist\vc_redist.x64.exe." Yellow
    }
}

# --- 4. Play (the game finds the UO data it carries in UOClient by itself) -----------------------------------------------------
Say "  Starting Ultima Skate (build $($Installed.build))..."
$LaunchArgs = @($GameArgs | Where-Object { $_ })
if ($LaunchArgs.Count -gt 0) {
    Start-Process -FilePath $Exe -ArgumentList $LaunchArgs -WorkingDirectory $Dir
} else {
    Start-Process -FilePath $Exe -WorkingDirectory $Dir
}