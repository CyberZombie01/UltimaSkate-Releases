<#
  Ultima Skate launcher: updates the game from GitHub (the releases repo in update.json), then starts it.

  - Reads the latest build's manifest from the repo's "game" release, downloads only the packs holding files that
    changed (checked by SHA-256), takes those files out of them, removes files the new build no longer has, and starts
    the game. A download cut short carries on where it stopped next time.
  - GitHub out of reach (no internet): plays the build you have.
  - Everything the game needs comes with it (the UO data it uses is in UOClient): nothing else to install.
  Started by "Play Ultima Skate.cmd". Extra arguments are passed to the game.
#>
param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GameArgs)
$ErrorActionPreference = "Stop"
$Dir = $PSScriptRoot
$State = Join-Path $Dir ".launcher"
New-Item -ItemType Directory -Force $State | Out-Null
$Host.UI.RawUI.WindowTitle = "Ultima Skate"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::DefaultConnectionLimit = 8
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

function Say($Text, $Color = "Gray") { Write-Host $Text -ForegroundColor $Color }
function ReadJson($Path) { if (Test-Path $Path) { Get-Content $Path -Raw | ConvertFrom-Json } else { $null } }
function SaveJson($Path, $Obj) { [IO.File]::WriteAllText($Path, ($Obj | ConvertTo-Json -Depth 5 -Compress), (New-Object Text.UTF8Encoding($false))) }

Say ""
Say "  ULTIMA SKATE" Yellow
Say ""

$Config = ReadJson (Join-Path $Dir "update.json")
$Installed = ReadJson (Join-Path $State "installed.json")

# --- GitHub's API (a public repo needs no token; a private one's token in update.json can only read it) ------------------
function Api($Path, $Accept = "application/vnd.github+json") {
    $R = [Net.HttpWebRequest]::Create("https://api.github.com$Path")
    if ($Config.token) { $R.Headers.Add("Authorization", "Bearer $($Config.token)") }
    $R.Headers.Add("X-GitHub-Api-Version", "2022-11-28")
    $R.Accept = $Accept
    $R.UserAgent = "UltimaSkateLauncher"
    $R.Timeout = 15000
    $R.ReadWriteTimeout = 30000
    $R.AllowAutoRedirect = $false
    return $R
}

function GetJson($Path) {
    $Resp = (Api $Path).GetResponse()
    try { (New-Object IO.StreamReader($Resp.GetResponseStream())).ReadToEnd() | ConvertFrom-Json } finally { $Resp.Close() }
}

# An asset's download address: GitHub answers with a short-lived link to the file itself.
function AssetUrl($Asset) {
    # (A public repo's files download straight from their link.)
    if (-not $Config.token -and $Asset.browser_download_url) { return $Asset.browser_download_url }
    $Resp = $null
    try {
        $Resp = (Api "/repos/$($Config.repo)/releases/assets/$($Asset.id)" "application/octet-stream").GetResponse()
        return $Resp.Headers["Location"]
    } catch [Net.WebException] {
        $Loc = if ($_.Exception.Response) { $_.Exception.Response.Headers["Location"] } else { $null }
        if ($Loc) { return $Loc }
        throw
    } finally { if ($Resp) { $Resp.Close() } }
}

# Downloads an asset to a file, carrying on from what's there; $OnBytes is told each chunk's size.
function Download($Asset, $To, $OnBytes) {
    $Buffer = New-Object byte[] (1MB)
    for ($Try = 1; $Try -le 4; $Try++) {
        try {
            $Start = if (Test-Path $To) { (Get-Item $To).Length } else { 0 }
            if ($Start -gt $Asset.size) { Remove-Item $To; $Start = 0 }
            if ($Start -eq $Asset.size) { return }
            $R = [Net.HttpWebRequest]::Create((AssetUrl $Asset))
            $R.UserAgent = "UltimaSkateLauncher"
            $R.Timeout = 15000
            $R.ReadWriteTimeout = 30000
            if ($Start -gt 0) { $R.AddRange([long]$Start) }
            $Resp = $R.GetResponse()
            $In = $Resp.GetResponseStream()
            $Out = New-Object IO.FileStream($To, [IO.FileMode]::Append)
            try {
                while (($N = $In.Read($Buffer, 0, $Buffer.Length)) -gt 0) {
                    $Out.Write($Buffer, 0, $N)
                    & $OnBytes $N
                }
            } finally { $Out.Close(); $Resp.Close() }
            if ((Get-Item $To).Length -eq $Asset.size) { return }
        } catch {
            if ($Try -eq 4) { throw }
            Start-Sleep -Seconds (2 * $Try)
        }
    }
    throw "the download stopped short"
}

# --- 1. The latest build ------------------------------------------------------------------------------------------------------
$Latest = $null
$Assets = @{}
if ($Config -and $Config.repo) {
    Say "  Checking for updates..."
    try {
        # (A handful of assets: the manifest and its packs.)
        $Release = GetJson "/repos/$($Config.repo)/releases/tags/game"
        foreach ($A in $Release.assets) { $Assets[$A.name] = $A }
        if ($Assets["manifest.json"]) {
            $MFile = Join-Path $State "manifest.json"
            if (Test-Path $MFile) { Remove-Item $MFile }
            Download $Assets["manifest.json"] $MFile { param($N) }
            $Latest = Get-Content $MFile -Raw | ConvertFrom-Json
        }
    } catch {
        $Code = if ($_.Exception.InnerException -and $_.Exception.InnerException.Response) { [int]$_.Exception.InnerException.Response.StatusCode } else { 0 }
        if ($Code -eq 401 -or $Code -eq 403 -or $Code -eq 404) {
            $Why = if ($Config.token) { "the token in update.json may have expired" } else { "the game's repo may be private now" }
            Say "  GitHub turned the update check down ($Code): $Why - ask your friend for a new Setup zip." Yellow
        }
        $Latest = $null
    }
}

# --- 2. Update ---------------------------------------------------------------------------------------------------------------
$Exe = Join-Path $Dir "UltimaSkate.exe"
if ($Latest) {
    $Have = @{}
    if ($Installed) { foreach ($F in $Installed.files) { $Have[$F.path] = $F } }
    $Need = @()
    foreach ($F in $Latest.files) {
        $Local = Join-Path $Dir ($F.path -replace '/', '\')
        $Old = $Have[$F.path]
        if (-not (Test-Path $Local) -or (Get-Item $Local).Length -ne $F.size) { $Need += $F; continue }
        if ($Old -and $Old.sha256 -eq $F.sha256) { continue }
        # Already there from an install that was cut short (or copied in): keep it if it's the right file.
        if ((Get-FileHash $Local -Algorithm SHA256).Hash.ToLower() -ne $F.sha256) { $Need += $F }
    }
    if ($Need.Count -eq 0) {
        Say ("  Up to date (build {0})." -f $Latest.build) Green
    } else {
        if (Get-Process UltimaSkate -ErrorAction SilentlyContinue) {
            Say "  Ultima Skate is still running - close it, then start Play Ultima Skate again." Yellow
            exit 1
        }
        # Windows can't handle paths over 260 characters: the folder has to be short enough for the game's deepest file.
        $Deepest = ($Latest.files | ForEach-Object { $_.path.Length } | Measure-Object -Maximum).Maximum
        if ($Dir.Length + 1 + $Deepest -gt 255) {
            Say "  This folder's path is too long for Windows. Move the Ultima Skate folder somewhere shorter," Red
            Say "  like Documents\Ultima Skate or C:\Games\Ultima Skate, and start it again."
            exit 1
        }
        # The packs holding what's needed.
        $ByPack = @{}
        foreach ($F in $Need) { if (-not $ByPack[$F.pack]) { $ByPack[$F.pack] = @() }; $ByPack[$F.pack] += $F }
        $PackSizes = @{}
        foreach ($P in $Latest.packs) { $PackSizes[$P.name] = [long]$P.size }
        $Bytes = 0L
        foreach ($P in $ByPack.Keys) { $Bytes += $PackSizes[$P] }
        $What = if ($Installed) { "Updating to build $($Latest.build)" } else { "Installing build $($Latest.build)" }
        Say ("  {0}: {1} files, {2:N0} MB to download" -f $What, $Need.Count, ($Bytes / 1MB)) Cyan
        if ($Latest.notes) { Say "  What's new: $($Latest.notes)" }
        $script:Done = 0L
        $Sw = [Diagnostics.Stopwatch]::StartNew()
        $Progress = {
            param($N)
            $script:Done += $N
            if ($Sw.ElapsedMilliseconds -gt 250) {
                $Sw.Restart()
                # ([long] 1: with a plain 1, PowerShell picks Max(int, int) and over 2 GB doesn't fit.)
                $Pct = [int](100 * $script:Done / [Math]::Max([long]1, $Bytes))
                Write-Progress -Activity $What -Status ("{0:N0} / {1:N0} MB" -f ($script:Done / 1MB), ($Bytes / 1MB)) -PercentComplete ([Math]::Min(100, $Pct))
            }
        }
        $Tmp = Join-Path $State "download"
        New-Item -ItemType Directory -Force $Tmp | Out-Null
        foreach ($P in $ByPack.Keys) {
            $Asset = $Assets[$P]
            $PackFile = Join-Path $Tmp $P
            try {
                if (-not $Asset) { throw "the update is missing $P" }
                Download $Asset $PackFile $Progress
                # Take the files out (each is in the pack once, named by its SHA-256) and check each one.
                $Zip = [IO.Compression.ZipFile]::OpenRead($PackFile)
                try {
                    foreach ($F in $ByPack[$P]) {
                        $Entry = $Zip.GetEntry($F.sha256)
                        if (-not $Entry) { throw "$P doesn't have $($F.path)" }
                        $Local = Join-Path $Dir ($F.path -replace '/', '\')
                        $Part = "$Local.part"
                        New-Item -ItemType Directory -Force (Split-Path $Local) | Out-Null
                        [IO.Compression.ZipFileExtensions]::ExtractToFile($Entry, $Part, $true)
                        if ((Get-FileHash $Part -Algorithm SHA256).Hash.ToLower() -ne $F.sha256) { Remove-Item $Part; throw "checksum mismatch on $($F.path)" }
                        Move-Item $Part $Local -Force
                    }
                } finally { $Zip.Dispose() }
                Remove-Item $PackFile -Force
            } catch {
                Write-Progress -Activity $What -Completed
                if ($_.Exception.Message -like "*checksum*" -or $_.Exception.Message -like "*doesn't have*") { Remove-Item $PackFile -Force -ErrorAction SilentlyContinue }
                Say "  Download failed ($P): $($_.Exception.Message)" Red
                Say "  Start Play Ultima Skate again to carry on where it stopped."
                exit 1
            }
        }
        Write-Progress -Activity $What -Completed
        # Files the new build no longer has (only ones an earlier build installed; your saves are never touched).
        if ($Installed) {
            $Keep = @{}
            foreach ($F in $Latest.files) { $Keep[$F.path] = $true }
            foreach ($F in $Installed.files) {
                if (-not $Keep[$F.path]) {
                    $Local = Join-Path $Dir ($F.path -replace '/', '\')
                    if (Test-Path $Local) { Remove-Item $Local -Force }
                }
            }
        }
        Say ("  Build {0} installed." -f $Latest.build) Green
    }
    SaveJson (Join-Path $State "installed.json") $Latest
    $Installed = $Latest
} elseif ($Installed -and (Test-Path $Exe)) {
    Say ("  Couldn't reach GitHub - playing build {0}." -f $Installed.build) Yellow
} else {
    Say "  Couldn't reach GitHub, and the game isn't installed yet." Red
    Say "  Check your internet connection and start Play Ultima Skate again."
    exit 1
}

# --- 3. The Windows runtime Unreal games need (first run only; Windows asks to allow it) --------------------------------------
$Prereq = Join-Path $Dir "Redist\vc_redist.x64.exe"
$Runtime = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\X64" -ErrorAction SilentlyContinue
if ((-not $Runtime -or $Runtime.Installed -ne 1) -and (Test-Path $Prereq) -and -not (Test-Path (Join-Path $State "prereqs.done"))) {
    Say "  Installing the Visual C++ runtime the game needs (one time)..."
    try {
        Start-Process -FilePath $Prereq -ArgumentList "/install", "/quiet", "/norestart" -Verb RunAs -Wait
        Set-Content (Join-Path $State "prereqs.done") "ok"
    } catch {
        Say "  Skipped the runtime install - if the game won't start, run Redist\vc_redist.x64.exe." Yellow
    }
}

# --- A shortcut with the game's icon (the Ultima Online deck) next to "Play Ultima Skate", to put on the desktop -----------------
$Link = Join-Path $Dir "Ultima Skate.lnk"
if ((Test-Path $Exe) -and -not (Test-Path $Link)) {
    try {
        $Shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($Link)
        $Shortcut.TargetPath = Join-Path $Dir "Play Ultima Skate.cmd"
        $Shortcut.WorkingDirectory = $Dir
        $Shortcut.IconLocation = "$Exe,0"
        $Shortcut.Description = "Update and play Ultima Skate"
        $Shortcut.Save()
        Say "  Made an 'Ultima Skate' shortcut in this folder - drag it to your desktop if you like."
    } catch { }
}

# --- 4. Play (the game finds the UO data it carries in UOClient by itself) -----------------------------------------------------
Say "  Starting Ultima Skate (build $($Installed.build))..."
$LaunchArgs = @($GameArgs | Where-Object { $_ })
if ($LaunchArgs.Count -gt 0) {
    Start-Process -FilePath $Exe -ArgumentList $LaunchArgs -WorkingDirectory $Dir
} else {
    Start-Process -FilePath $Exe -WorkingDirectory $Dir
}
